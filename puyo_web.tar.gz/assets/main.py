import pygame
import sys
import random
import math
import array
import os
import asyncio
import platform

pygame.init()

sound_enabled = True

try:
    pygame.mixer.init(frequency=44100, size=-16, channels=2)

    def make_sound(freq, duration=0.08, volume=0.35):
        sample_rate = 44100
        n_samples = int(sample_rate * duration)
        buf = array.array("h")
        for i in range(n_samples):
            t = i / sample_rate
            wave = math.sin(2 * math.pi * freq * t)
            envelope = max(0, 1 - t / duration)
            buf.append(int(32767 * volume * wave * envelope))
        return pygame.mixer.Sound(buffer=buf)

    def make_cat_sound(chain_count=1):
        sample_rate = 44100
        duration = min(0.18 + chain_count * 0.05, 0.45)
        n_samples = int(sample_rate * duration)
        buf = array.array("h")
        base = 520 + chain_count * 90
        for i in range(n_samples):
            t = i / sample_rate
            freq = base + math.sin(t * 55) * 220
            wave = (
                math.sin(2 * math.pi * freq * t) * 0.7 +
                math.sin(2 * math.pi * freq * 1.8 * t) * 0.3
            )
            envelope = max(0, 1 - t / duration)
            buf.append(int(32767 * 0.35 * wave * envelope))
        return pygame.mixer.Sound(buffer=buf)

    def make_gameover_cat_sound():
        sample_rate = 44100
        duration = 0.75
        n_samples = int(sample_rate * duration)
        buf = array.array("h")
        for i in range(n_samples):
            t = i / sample_rate
            freq = 520 - t * 260
            wave = math.sin(2 * math.pi * freq * t)
            envelope = max(0, 1 - t / duration)
            buf.append(int(32767 * 0.32 * wave * envelope))
        return pygame.mixer.Sound(buffer=buf)

    def make_bgm_loop(notes, bpm=100, volume=0.08):
        sample_rate = 44100
        beat = 60 / bpm
        note_duration = beat / 2
        total_duration = note_duration * len(notes)
        n_samples = int(sample_rate * total_duration)
        buf = array.array("h")
        for i in range(n_samples):
            t = i / sample_rate
            index = int(t / note_duration) % len(notes)
            freq = notes[index]
            wave = (
                math.sin(2 * math.pi * freq * t) * 0.7 +
                math.sin(2 * math.pi * freq * 2 * t) * 0.25
            )
            buf.append(int(32767 * volume * wave))
        return pygame.mixer.Sound(buffer=buf)

    def make_chain_sound(chain_count):
        sample_rate = 44100
        duration = min(0.35 + chain_count * 0.08, 0.9)
        n_samples = int(sample_rate * duration)
        buf = array.array("h")
        base = 800 + chain_count * 180
        for i in range(n_samples):
            t = i / sample_rate
            freq1 = base + t * 1800
            freq2 = base * 1.5 + t * 2600
            wave = math.sin(2 * math.pi * freq1 * t) * 0.6 + math.sin(2 * math.pi * freq2 * t) * 0.4
            envelope = max(0, 1 - t / duration)
            buf.append(int(32767 * 0.5 * wave * envelope))
        return pygame.mixer.Sound(buffer=buf)

    
    def make_levelup_jingle():
        sample_rate = 44100
        notes = [659, 784, 988, 1318]
        note_duration = 0.12
        total_duration = note_duration * len(notes)
        n_samples = int(sample_rate * total_duration)
        buf = array.array("h")

        for i in range(n_samples):
            t = i / sample_rate
            index = min(int(t / note_duration), len(notes) - 1)
            local_t = t - index * note_duration
            freq = notes[index]

            wave = (
                math.sin(2 * math.pi * freq * local_t) * 0.75 +
                math.sin(2 * math.pi * freq * 2 * local_t) * 0.25
            )

            envelope = max(0, 1 - local_t / note_duration)
            buf.append(int(32767 * 0.28 * wave * envelope))

        return pygame.mixer.Sound(buffer=buf)
    
    def make_lucky_jingle():
        sample_rate = 44100
        notes = [659, 784, 988, 1318, 1760]
        note_duration = 0.09
        total_duration = note_duration * len(notes)
        n_samples = int(sample_rate * total_duration)
        buf = array.array("h")

        for i in range(n_samples):
            t = i / sample_rate
            index = min(int(t / note_duration), len(notes) - 1)
            local_t = t - index * note_duration
            freq = notes[index]

            wave = (
                math.sin(2 * math.pi * freq * local_t) * 0.75 +
                math.sin(2 * math.pi * freq * 2 * local_t) * 0.25
        )

            envelope = max(0, 1 - local_t / note_duration)
            buf.append(int(32767 * 0.35 * wave * envelope))

        return pygame.mixer.Sound(buffer=buf)

    sound_start = make_sound(784, 0.25, 0.3)
    sound_move = make_sound(330, 0.04, 0.2)
    sound_rotate = make_sound(520, 0.05, 0.25)
    sound_clear = make_sound(900, 0.22, 0.45)
    sound_drop = make_sound(220, 0.05, 0.2)
    sound_ojama = make_sound(140, 0.18, 0.35)
    sound_levelup = make_levelup_jingle()
    sound_lucky = make_lucky_jingle()
    sound_gameover_cat = make_gameover_cat_sound()

    bgm_title = make_bgm_loop([392, 523, 659, 523], bpm=80, volume=0.025)
    bgm_normal = make_bgm_loop([523, 659, 784, 659, 523, 659, 698, 659], bpm=95, volume=0.022)
    bgm_mid = make_bgm_loop([659, 784, 880, 784, 659, 784, 988, 784], bpm=125, volume=0.024)
    bgm_fast = make_bgm_loop([784, 988, 1175, 988, 880, 1046, 1318, 1046], bpm=155, volume=0.026)

    bgm_channel = pygame.mixer.Channel(0)
    current_bgm = None

except Exception:
    sound_enabled = False
    current_bgm = None


def play(sound):
    if sound_enabled:
        sound.play()


def stop_bgm():
    global current_bgm

    if sound_enabled:
        pygame.mixer.music.stop()
        bgm_channel.stop()

    current_bgm = None


def change_bgm(mode):
    global current_bgm

    if not sound_enabled or current_bgm == mode:
        return

    external_bgm = {
        "title": "bgm_title.ogg",
        "normal": "bgm_normal.ogg",
        "mid": "bgm_mid.ogg",
        "fast": "bgm_fast.ogg",
    }

    generated_bgm = {
        "title": bgm_title,
        "normal": bgm_normal,
        "mid": bgm_mid,
        "fast": bgm_fast,
    }

    current_bgm = mode
    filename = external_bgm.get(mode)

    if filename and os.path.exists(filename):
        try:
            bgm_channel.stop()
            pygame.mixer.music.load(filename)
            pygame.mixer.music.set_volume(0.25)
            pygame.mixer.music.play(-1)
            return
        except Exception as e:
            print("External BGM error:", e)

    try:
        pygame.mixer.music.stop()
        bgm_channel.stop()
        bgm_channel.play(generated_bgm[mode], loops=-1)
    except Exception as e:
        print("Generated BGM error:", e)

# ===== DEBUG SETTINGS =====
DEBUG_MODE = False
DEBUG_LEVEL = 9


WIDTH = 430
HEIGHT = 700
PLAY_HEIGHT = 600
FIELD_WIDTH = 300
CELL = 30
HIGHSCORE_FILE = "puyo_highscore.txt"

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mini Puyo Step18 CAT EX")

clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 28)
big_font = pygame.font.SysFont(None, 42)
title_font = pygame.font.SysFont(None, 54)
jp_font = pygame.font.SysFont("Yu Gothic", 26)
jp_big_font = pygame.font.SysFont("Yu Gothic", 42)


base_colors = [
    (255, 120, 160),
    (100, 235, 120),
    (100, 160, 255),
    (250, 250, 235)
]

extra_color = (180, 100, 255)

LUCKY_COLOR = (255, 215, 0)

OJAMA_COLOR = (170, 170, 170)


field = []
fading_puyos = []

score = 0
level = 1
previous_level = 1
final_level = 1
game_over = False
game_started = False
show_help = False
paused = False
gameover_effect_played = False

fall_timer = 0
base_fall_speed = 22

move_cooldown = 0
rotate_cooldown = 0
drop_cooldown = 0
ojama_timer = 0

chain_message = ""
chain_message_timer = 0

level_message = ""
level_message_timer = 0
boss_message_timer = 0

lucky_message_timer = 0

shake_timer = 0
shake_power = 0
flash_timer = 0
continue_timer = 0
continue_limit = 300

frame_count = 0

puyo_x = FIELD_WIDTH // 2
puyo_y = 0
visual_puyo_x = puyo_x
visual_puyo_y = puyo_y
rotation = 0

color1 = random.choice(base_colors)
color2 = random.choice(base_colors)
next_color1 = random.choice(base_colors)
next_color2 = random.choice(base_colors)


def load_highscore():
    if not os.path.exists(HIGHSCORE_FILE):
        return 0
    try:
        with open(HIGHSCORE_FILE, "r", encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return 0


def save_highscore(value):
    try:
        with open(HIGHSCORE_FILE, "w", encoding="utf-8") as f:
            f.write(str(value))
    except Exception:
        pass


highscore = load_highscore()


def start_shake(power=4, duration=12):
    global shake_power, shake_timer
    shake_power = power
    shake_timer = duration


def start_flash(duration=18):
    global flash_timer
    flash_timer = duration


def get_shake_offset():
    if shake_timer <= 0:
        return 0, 0
    return random.randint(-shake_power, shake_power), random.randint(-shake_power, shake_power)


def get_current_colors():
    if level >= 8:
        return base_colors + [extra_color]
    return base_colors

def random_puyo_color():
    if random.random() < 0.02:
        return LUCKY_COLOR
    return random.choice(get_current_colors())


def new_puyo():
    global puyo_x, puyo_y, visual_puyo_x, visual_puyo_y
    global color1, color2, next_color1, next_color2, rotation

    puyo_x = FIELD_WIDTH // 2
    puyo_y = 0
    visual_puyo_x = puyo_x
    visual_puyo_y = puyo_y
    rotation = 0

    color1 = next_color1
    color2 = next_color2
    next_color1 = random_puyo_color()
    next_color2 = random_puyo_color()


def update_visual_position():
    global visual_puyo_x, visual_puyo_y

    visual_puyo_x += (puyo_x - visual_puyo_x) * 0.35
    visual_puyo_y += (puyo_y - visual_puyo_y) * 0.35

    if abs(visual_puyo_x - puyo_x) < 0.5:
        visual_puyo_x = puyo_x
    if abs(visual_puyo_y - puyo_y) < 0.5:
        visual_puyo_y = puyo_y


def get_positions(x, y, rot):
    if rot == 0:
        return [(x, y), (x, y + CELL)]
    elif rot == 1:
        return [(x, y), (x + CELL, y)]
    elif rot == 2:
        return [(x, y), (x, y - CELL)]
    elif rot == 3:
        return [(x, y), (x - CELL, y)]


def is_collision(x, y, rot):
    for px, py in get_positions(x, y, rot):
        if px < 0 or px > FIELD_WIDTH - CELL or py >= PLAY_HEIGHT:
            return True
        for fx, fy, _ in field:
            if px == fx and py == fy:
                return True
    return False


def fix_puyo():
    for (px, py), color in zip(get_positions(puyo_x, puyo_y, rotation), [color1, color2]):
        field.append((px, py, color))

def is_same_group_color(base_color, target_color):
    if target_color == LUCKY_COLOR:
        return True
    if base_color == LUCKY_COLOR:
        return target_color != OJAMA_COLOR
    return target_color == base_color


def find_groups():
    visited = set()
    groups = []

    for x, y, color in field:
        if color == OJAMA_COLOR or (x, y) in visited:
            continue

        stack = [(x, y)]
        group = []
        visited.add((x, y))

        while stack:
            cx, cy = stack.pop()
            group.append((cx, cy))

            for dx, dy in [(CELL, 0), (-CELL, 0), (0, CELL), (0, -CELL)]:
                nx = cx + dx
                ny = cy + dy

                for fx, fy, fcolor in field:
                    if (fx, fy) == (nx, ny) and is_same_group_color(color, fcolor) and (nx, ny) not in visited:
                        visited.add((nx, ny))
                        stack.append((nx, ny))

        if len(group) >= 4:
            groups.append(group)

    return groups


def add_fade_effect(remove_set):
    for x, y, color in field:
        if (x, y) in remove_set:
            fading_puyos.append({
                "x": x,
                "y": y,
                "color": color,
                "timer": 18,
                "max_timer": 18
            })


def update_fading_puyos():
    global fading_puyos

    new_list = []
    for item in fading_puyos:
        item["timer"] -= 1
        if item["timer"] > 0:
            new_list.append(item)

    fading_puyos = new_list


def clear_groups(chain_count):
    global field, score, level, previous_level
    global chain_message, chain_message_timer, level_message, level_message_timer
    global boss_message_timer, lucky_message_timer

    groups = find_groups()

    if not groups:
        return False

    remove_set = set()

    for group in groups:
        for pos in group:
            remove_set.add(pos)

    for x, y, color in field:
        if color == OJAMA_COLOR:
            for gx, gy in list(remove_set):
                if abs(x - gx) + abs(y - gy) == CELL:
                    remove_set.add((x, y))
                    break

    add_fade_effect(remove_set)

    erased_count = len(remove_set)

    lucky_hit = False

    for x, y, color in field:
        if (x, y) in remove_set and color == LUCKY_COLOR:
            lucky_hit = True
            break

    score += erased_count * 10 * chain_count

    if lucky_hit:
        score += 500
        clear_all_ojama()
        lucky_message_timer = 120
        start_shake(power=8, duration=25)
        start_flash(duration=30)
        play(sound_lucky)

    level = score // 500 + 1

    if level > previous_level:
        
        level_message = f"LEVEL {level}!"
        level_message_timer = 60

        if level == 10:
            boss_message_timer = 120
            start_shake(power=12, duration=40)
            start_flash(duration=40)

        previous_level = level
        play(sound_levelup)

    if chain_count >= 2:
        if chain_count == 2:
            chain_message = "2 Chain!"
        elif chain_count == 3:
            chain_message = "CAT COMBO!!"
        elif chain_count == 4:
            chain_message = "SUPER CAT!!"
        else:
            chain_message = "MEGA CAT!!"

        chain_message_timer = 45
        play(make_chain_sound(chain_count))
        play(make_cat_sound(chain_count))
        start_shake(power=min(10, 4 + chain_count), duration=14 + chain_count * 3)

        if chain_count >= 3:
            start_flash(duration=20)
    else:
        chain_message = "Nice!"
        chain_message_timer = 25
        play(sound_clear)
        play(make_cat_sound(1))
        start_shake(power=2, duration=7)

    field = [(x, y, color) for x, y, color in field if (x, y) not in remove_set]
    return True


def apply_gravity():
    global field

    changed = True
    while changed:
        changed = False
        new_field = []
        sorted_field = sorted(field, key=lambda p: p[1], reverse=True)
        occupied = set()

        for x, y, color in sorted_field:
            new_y = y
            while new_y + CELL < PLAY_HEIGHT and (x, new_y + CELL) not in occupied:
                blocked = False
                for ox, oy, _ in field:
                    if ox == x and oy == new_y + CELL:
                        blocked = True
                        break
                if blocked:
                    break
                new_y += CELL
                changed = True

            occupied.add((x, new_y))
            new_field.append((x, new_y, color))

        field = new_field


def resolve_chain():
    chain_count = 1
    while True:
        cleared = clear_groups(chain_count)
        if not cleared:
            break
        apply_gravity()
        chain_count += 1


def get_fall_speed():
    if level <= 3:
        return base_fall_speed

    if level <= 6:
        return max(14, base_fall_speed - (level - 3) * 2)

    speed = 14 - (level - 6)
    return max(4, speed)

def update_game_bgm():
    try:
        if level >= 10:
            platform.window.changeBGM("fast")
        else:
            platform.window.changeBGM("normal")
    except Exception:
        pass

def add_soft_ojama():
    global field, game_over

    new_field = []

    for x, y, color in field:
        new_y = y - CELL
        if new_y < 0:
            game_over = True
        new_field.append((x, new_y, color))

    total_cols = FIELD_WIDTH // CELL
    empty_cols = random.sample(range(total_cols), 2)

    for col in range(total_cols):
        if col not in empty_cols:
            new_field.append((col * CELL, PLAY_HEIGHT - CELL, OJAMA_COLOR))

    field = new_field
    play(sound_ojama)
    start_shake(power=4, duration=10)

def clear_all_ojama():
    global field

    remove_set = set()

    for x, y, color in field:
        if color == OJAMA_COLOR:
            remove_set.add((x, y))

    if remove_set:
        add_fade_effect(remove_set)

    field = [
        (x, y, color)
        for x, y, color in field
        if color != OJAMA_COLOR
    ]
    
def draw_puyo(x, y, color, radius=None, sad=False, alpha=255):
    if radius is None:
        radius = CELL // 2 - 2

    surface = pygame.Surface((CELL + 18, CELL + 18), pygame.SRCALPHA)
    ox = CELL // 2 + 9
    oy = CELL // 2 + 9

    if color == OJAMA_COLOR:
        pygame.draw.circle(surface, (*color, alpha), (ox, oy), radius)
        pygame.draw.circle(surface, (100, 100, 100, alpha), (ox, oy), radius, 2)
        pygame.draw.circle(surface, (220, 220, 220, alpha), (ox - 5, oy - 5), max(2, radius // 4))
        screen.blit(surface, (x - 9, y - 9))
        return

    tail_angle = math.sin(frame_count * 0.18 + x * 0.03 + y * 0.02) * 5
    tail_color = (
        max(color[0] - 40, 0),
        max(color[1] - 40, 0),
        max(color[2] - 40, 0),
        alpha
    )
    tail_start = (ox + radius - 3, oy + 3)
    tail_mid = (ox + radius + 5, oy - 2 + int(tail_angle))
    tail_end = (ox + radius + 1, oy - 8 + int(tail_angle))
    pygame.draw.lines(surface, tail_color, False, [tail_start, tail_mid, tail_end], 3)

    if color == LUCKY_COLOR:
        pulse = int(math.sin(frame_count * 0.25) * 2)

        pygame.draw.circle(
            surface,
            (255, 240, 120, alpha),
            (ox, oy),
            radius + 4 + pulse
        )

         # Lucky Star
        star_color = (255, 240, 80, alpha)

        pygame.draw.line(
            surface,
            star_color,
            (ox, oy - radius),
            (ox, oy - radius + 8),
            2,
        )

        pygame.draw.line(
            surface,
            star_color,
            (ox - 3, oy - radius + 5),
            (ox + 3, oy - radius + 5),
            2,
        )
        pygame.draw.line(
            surface,
            star_color,
            (ox - 2, oy - radius + 3),
            (ox + 2, oy - radius + 7),
            2,
        )

        pygame.draw.line(
            surface,
            star_color,
            (ox + 2, oy - radius + 3),
            (ox - 2, oy - radius + 7),
            2,
        )
        
    pygame.draw.circle(surface, (*color, alpha), (ox, oy), radius)

    pygame.draw.polygon(surface, (*color, alpha), [(ox - 10, oy - radius + 6), (ox - 4, oy - radius - 3), (ox + 1, oy - radius + 7)])
    pygame.draw.polygon(surface, (*color, alpha), [(ox + 10, oy - radius + 6), (ox + 4, oy - radius - 3), (ox - 1, oy - radius + 7)])

    pygame.draw.circle(surface, (255, 255, 255, alpha), (ox - 6, oy - 7), max(2, radius // 4))

    eye_y = oy - 1
    if sad:
        pygame.draw.arc(surface, (20, 20, 30, alpha), (ox - 9, eye_y - 4, 8, 6), math.pi, 2 * math.pi, 2)
        pygame.draw.arc(surface, (20, 20, 30, alpha), (ox + 1, eye_y - 4, 8, 6), math.pi, 2 * math.pi, 2)
        pygame.draw.arc(surface, (40, 20, 30, alpha), (ox - 5, oy + 8, 10, 8), math.pi, 2 * math.pi, 1)
    else:
        pygame.draw.circle(surface, (255, 255, 255, alpha), (ox - 5, eye_y), max(3, radius // 4))
        pygame.draw.circle(surface, (255, 255, 255, alpha), (ox + 5, eye_y), max(3, radius // 4))
        pygame.draw.circle(surface, (20, 20, 30, alpha), (ox - 5, eye_y), max(1, radius // 7))
        pygame.draw.circle(surface, (20, 20, 30, alpha), (ox + 5, eye_y), max(1, radius // 7))
        pygame.draw.arc(surface, (40, 20, 30, alpha), (ox - 4, oy + 2, 8, 6), 0, math.pi, 1)

    cheek = (255, 140, 170)
    pygame.draw.circle(surface, (*cheek, alpha), (ox - 9, oy + 5), max(2, radius // 5))
    pygame.draw.circle(surface, (*cheek, alpha), (ox + 9, oy + 5), max(2, radius // 5))

    screen.blit(surface, (x - 9, y - 9))


def draw_fading_puyos():
    for item in fading_puyos:
        ratio = item["timer"] / item["max_timer"]
        alpha = int(255 * ratio)
        radius = int((CELL // 2 - 2) + (1 - ratio) * 10)
        draw_puyo(item["x"], item["y"], item["color"], radius=radius, alpha=alpha)


def draw_flash():
    if flash_timer <= 0:
        return

    alpha = int(90 * (flash_timer / 20))
    overlay = pygame.Surface((FIELD_WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((255, 240, 160, alpha))
    screen.blit(overlay, (0, 0))


def draw_next():
    screen.blit(font.render("NEXT", True, (255, 255, 255)), (315, 185))
    draw_puyo(320, 220, next_color1, 10)
    draw_puyo(320, 245, next_color2, 10)

# ===== スマホ操作ボタン =====

BUTTON_Y = HEIGHT - 80

LEFT_BUTTON = pygame.Rect(25, BUTTON_Y, 60, 50)
RIGHT_BUTTON = pygame.Rect(100, BUTTON_Y, 60, 50)
ROTATE_BUTTON = pygame.Rect(180, BUTTON_Y, 75, 50)
DOWN_BUTTON = pygame.Rect(260, BUTTON_Y, 70, 50)
PAUSE_BUTTON = pygame.Rect(315, 520, 95, 45)

def draw_button_text(text, rect, use_big=False):
    f = big_font if use_big else font
    img = f.render(text, True, (255,255,255))
    x = rect.x + (rect.width - img.get_width()) // 2
    y = rect.y + (rect.height - img.get_height()) // 2
    screen.blit(img, (x, y))

def draw_mobile_buttons():
    pygame.draw.rect(screen, (80, 80, 120), LEFT_BUTTON, border_radius=10)
    pygame.draw.rect(screen, (80, 80, 120), RIGHT_BUTTON, border_radius=10)
    pygame.draw.rect(screen, (120, 80, 120), ROTATE_BUTTON, border_radius=10)
    pygame.draw.rect(screen, (120, 80, 80), DOWN_BUTTON, border_radius=10)
    pygame.draw.rect(screen, (80, 100, 140), PAUSE_BUTTON, border_radius=10)

    draw_button_text("L", LEFT_BUTTON, use_big=True)
    draw_button_text("R", RIGHT_BUTTON, use_big=True)
    draw_button_text("ROT", ROTATE_BUTTON)
    draw_button_text("FAST", DOWN_BUTTON)
    draw_button_text("PAUSE", PAUSE_BUTTON)

def reset_game():
    global field, fading_puyos, score, level, previous_level, final_level
    global game_over, gameover_effect_played, ojama_timer, continue_timer
    global next_color1, next_color2, chain_message, chain_message_timer
    global level_message, level_message_timer, flash_timer

    field = []
    fading_puyos = []
    score = 0
    level = 1
    previous_level = 1

    if DEBUG_MODE:
        level = DEBUG_LEVEL
        previous_level = DEBUG_LEVEL
        score = (DEBUG_LEVEL - 1) * 500
    
    final_level = 1
    game_over = False
    gameover_effect_played = False
    ojama_timer = 0
    continue_timer = 0
    chain_message = ""
    chain_message_timer = 0
    level_message = ""
    level_message_timer = 0
    flash_timer = 0

    next_color1 = random.choice(base_colors)
    next_color2 = random.choice(base_colors)
    new_puyo()

    # change_bgm("normal")


def draw_stars():
    for i in range(24):
        x = (i * 47 + frame_count * (1 + i % 3)) % WIDTH
        y = (i * 73 + frame_count // 2) % HEIGHT
        size = 1 + (i % 3)
        pygame.draw.circle(screen, (255, 240, 180), (x, y), size)


def draw_title_screen():
    # change_bgm("title")

    screen.fill((12, 12, 28))
    draw_stars()

    float_y = int(math.sin(frame_count * 0.05) * 8)
    blink = (frame_count // 45) % 6 == 0

    title = title_font.render("Mini Puyo", True, (255, 230, 255))
    cat_ex = big_font.render("CAT EX", True, (255, 210, 120))
    subtitle = font.render("Cute Chain Puzzle", True, (220, 220, 255))

    screen.blit(title, (75, 105 + float_y))
    screen.blit(cat_ex, (135, 160 + float_y))
    screen.blit(subtitle, (105, 205))

    start_color = (255, 255, 255) if (frame_count // 20) % 2 == 0 else (180, 180, 220)
    start = font.render("Tap / Press SPACE", True, start_color)
    screen.blit(start, (95, 430))

    draw_puyo(95, 260 + float_y // 2, base_colors[0], sad=blink)
    draw_puyo(135, 260 - float_y // 2, base_colors[1], sad=blink)
    draw_puyo(175, 260 + float_y // 2, base_colors[2], sad=blink)
    draw_puyo(215, 260 - float_y // 2, base_colors[3], sad=blink)

    draw_puyo(135, 305 + float_y // 2, base_colors[3])
    draw_puyo(175, 305 - float_y // 2, base_colors[0])

def draw_help_screen():
    screen.fill((15, 15, 35))

    title = jp_big_font.render("HOW TO PLAY", True, (255, 220, 120))
    screen.blit(title, (70, 40))

    lines = [
        "Connect 4 Colors!",
        "4 Shoku Narabeyou !",
        "",
        "Speed gets faster!",
        "Level Up De Speed Up",
        "",
        "Watch out for Gray Puyos!",
        "Level 5 Ojyama Puyo Toujyo!",
        "",
        "L / R  Move",
        "ROT    Rotate",
        "FAST   Drop Fast",
        "PAUSE  Ichiji Teishi",
        "",
        "Tap / Press SPACE"
    ]

    y = 110

    for line in lines:
        text = jp_font.render(line, True, (255, 255, 255))
        screen.blit(text, (70, y))
        y += 35
    draw_puyo(70, 565, OJAMA_COLOR)

    ojama_text = jp_font.render("Gray Puyo = Ojyama!", True, (255,255,255))
    screen.blit(ojama_text, (110, 565))

        
new_puyo()

if DEBUG_MODE:
    level = DEBUG_LEVEL
    previous_level = DEBUG_LEVEL
    score = (DEBUG_LEVEL - 1) * 500

async def main():
    global frame_count, game_started, show_help, paused, game_over, gameover_effect_played
    global fall_timer, move_cooldown, rotate_cooldown, drop_cooldown
    global chain_message_timer, level_message_timer, flash_timer
    global boss_message_timer
    global lucky_message_timer
    global ojama_timer, continue_timer, final_level, highscore
    global shake_timer, puyo_x, puyo_y, rotation, score

    while True:
        frame_count += 1

        start_pressed = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                start_pressed = True

            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                paused = not paused

                if paused:
                    try:
                        platform.window.pauseBGM()
                    except Exception:
                        pass
                else:
                    try:
                        platform.window.resumeBGM()
                    except Exception:
                        pass

            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                reset_game()
                paused = False

                try:
                    platform.window.resumeBGM()
                except Exception:
                    pass
                
            if paused and event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                if 90 <= mx <= 270 and 380 <= my <= 445:
                    paused = False

                    try:
                        platform.window.resumeBGM()
                    except Exception:
                        pass

                if 90 <= mx <= 270 and 470 <= my <= 535:
                    reset_game()
                    paused = False

                    try:
                        platform.window.resumeBGM()
                    except Exception:
                        pass

                continue

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                if game_started and not show_help and not game_over and not paused:
                    if PAUSE_BUTTON.collidepoint((mx, my)):
                        paused = True

                        try:
                            platform.window.pauseBGM()
                        except Exception:
                            pass

                        continue

                start_pressed = True

        keys = pygame.key.get_pressed()
        mouse_pressed = pygame.mouse.get_pressed()[0]
        mouse_pos = pygame.mouse.get_pos()

        if paused:
            screen.fill((0, 0, 30))

            text = big_font.render("PAUSED", True, (255, 220, 120))
            screen.blit(text, (80, 180))

            text2 = font.render("Press P to Resume", True, (255, 255, 255))
            screen.blit(text2, (90, 280))

            text3 = font.render("Press R to Restart", True, (255, 255, 255))
            screen.blit(text3, (85, 330))

            pygame.draw.rect(screen, (80, 120, 180), (90, 380, 180, 65))
            pygame.draw.rect(screen, (180, 100, 100), (90, 470, 180, 65))

            resume_text = font.render("RESUME", True, (255,255,255))
            restart_text = font.render("RESTART", True, (255,255,255))

            sub1 = font.render("Tsuzuki Kara", True, (255,255,255))
            sub2 = font.render("Saisho Kara", True, (255,255,255))

            screen.blit(resume_text, (120, 390))
            screen.blit(sub1, (105, 418))

            screen.blit(restart_text, (115, 480))
            screen.blit(sub2, (105, 508))

            pygame.display.update()
            clock.tick(30)
            await asyncio.sleep(0)
            continue


        if not game_started and not show_help:
            if start_pressed:
                show_help = True
                play(sound_start)

            draw_title_screen()
            pygame.display.update()
            clock.tick(30)
            await asyncio.sleep(0)
            continue


        if show_help and not game_started:
            if start_pressed:
                game_started = True
                show_help = False

                try:
                    platform.window.changeBGM("normal")
                except Exception:
                    pass

            draw_help_screen()
            pygame.display.update()
            clock.tick(30)
            await asyncio.sleep(0)
            continue

        update_game_bgm()
        update_fading_puyos()

        if not game_over:
            update_visual_position()

            if move_cooldown > 0:
                move_cooldown -= 1
            if rotate_cooldown > 0:
                rotate_cooldown -= 1
            if drop_cooldown > 0:
                drop_cooldown -= 1
            if chain_message_timer > 0:
                chain_message_timer -= 1
            if level_message_timer > 0:
                level_message_timer -= 1
            if boss_message_timer > 0:
                boss_message_timer -= 1
            if lucky_message_timer > 0:
                lucky_message_timer -= 1
            if flash_timer > 0:
                flash_timer -= 1

            if move_cooldown == 0:
                left_pressed = keys[pygame.K_LEFT] or (mouse_pressed and LEFT_BUTTON.collidepoint(mouse_pos))
                right_pressed = keys[pygame.K_RIGHT] or (mouse_pressed and RIGHT_BUTTON.collidepoint(mouse_pos))

                if left_pressed and not is_collision(puyo_x - CELL, puyo_y, rotation):
                    puyo_x -= CELL
                    move_cooldown = 5
                    play(sound_move)

                if right_pressed and not is_collision(puyo_x + CELL, puyo_y, rotation):
                    puyo_x += CELL
                    move_cooldown = 5
                    play(sound_move)
            

            rotate_pressed = keys[pygame.K_SPACE] or (mouse_pressed and ROTATE_BUTTON.collidepoint(mouse_pos))

            if rotate_pressed and rotate_cooldown == 0:
                new_rot = (rotation + 1) % 4
                if not is_collision(puyo_x, puyo_y, new_rot):
                    rotation = new_rot
                    play(sound_rotate)
                rotate_cooldown = 10

            down_pressed = keys[pygame.K_DOWN] or (mouse_pressed and DOWN_BUTTON.collidepoint(mouse_pos))

            if down_pressed and drop_cooldown == 0:
                if not is_collision(puyo_x, puyo_y + CELL, rotation):
                    puyo_y += CELL
                    score += 1
                    play(sound_drop)
                drop_cooldown = 3

            fall_timer += 1

            if fall_timer >= get_fall_speed():
                fall_timer = 0

                if is_collision(puyo_x, puyo_y + CELL, rotation):
                    fix_puyo()
                    resolve_chain()
                    new_puyo()

                    if is_collision(puyo_x, puyo_y, rotation):
                        game_over = True
                        continue_timer = continue_limit
                        final_level = level
                        if score > highscore:
                            highscore = score
                            save_highscore(highscore)
                else:
                    puyo_y += CELL

            ojama_timer += 1
            if level >= 5 and ojama_timer >= 900:
                add_soft_ojama()
                ojama_timer = 0

                if game_over:
                    continue_timer = continue_limit
                    final_level = level
                    if score > highscore:
                        highscore = score
                        save_highscore(highscore)

        else:
            if not gameover_effect_played:
                stop_bgm()
                play(sound_gameover_cat)
                start_shake(power=6, duration=18)
                gameover_effect_played = True

            if continue_timer > 0:
                continue_timer -= 1
                if keys[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]:
                    reset_game()

            if keys[pygame.K_r]:
                reset_game()

        if shake_timer > 0:
            shake_timer -= 1

        shake_x, shake_y = get_shake_offset()

        if level < 5:
            bg_color = (0, 0, 0)

        elif level < 10:
            bg_color = (60, 20, 0)

        elif level < 15:
            bg_color = (0, 20, 80)

        else:
            bg_color = (50, 0, 100)
        
        screen.fill(bg_color)

        pygame.draw.rect(screen, (45, 45, 45), (FIELD_WIDTH, 0, WIDTH - FIELD_WIDTH, HEIGHT))

        for fx, fy, color in field:
            draw_puyo(fx + shake_x, fy + shake_y, color)

        draw_fading_puyos()
        draw_flash()

        if not game_over:
            pos = get_positions(visual_puyo_x, visual_puyo_y, rotation)
            draw_puyo(pos[0][0] + shake_x, pos[0][1] + shake_y, color1)
            draw_puyo(pos[1][0] + shake_x, pos[1][1] + shake_y, color2)

        screen.blit(font.render("Score", True, (255, 255, 255)), (315, 20))
        screen.blit(big_font.render(str(score), True, (255, 255, 255)), (315, 45))

        screen.blit(font.render("High", True, (255, 255, 255)), (315, 85))
        screen.blit(font.render(str(highscore), True, (255, 255, 120)), (315, 112))

        screen.blit(font.render("Level", True, (255, 255, 255)), (315, 140))
        screen.blit(big_font.render(str(level), True, (255, 255, 255)), (315, 160))

        draw_next()
        draw_mobile_buttons()

        screen.blit(font.render("Touch", True, (255, 255, 255)), (315, 320))
        screen.blit(font.render("L / R", True, (255, 255, 255)), (315, 350))
        screen.blit(font.render("ROT", True, (255, 255, 255)), (315, 380))
        screen.blit(font.render("FAST", True, (255, 255, 255)), (315, 410))

        if level >= 8:
            screen.blit(font.render("+Purple", True, extra_color), (315, 455))

        if chain_message_timer > 0 and lucky_message_timer == 0:
            chain_text = big_font.render(chain_message, True, (255, 255, 120))
            screen.blit(chain_text, (85 + shake_x, 250 + shake_y))
            
        if lucky_message_timer > 0:

            overlay = pygame.Surface((FIELD_WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((40, 20, 0, 120))
            screen.blit(overlay, (0, 0))

            lucky1 = title_font.render("LUCKY CAT!!", True, (255, 255, 120))
            lucky_bonus = big_font.render("BONUS!!", True, (255, 180, 80))
            lucky2 = big_font.render("+500", True, (255, 220, 0))

            screen.blit(lucky1, (20, 210))
            screen.blit(lucky_bonus, (75, 270))
            screen.blit(lucky2, (90, 320))

        elif boss_message_timer > 0:

            overlay = pygame.Surface((FIELD_WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 120))
            screen.blit(overlay, (0, 0))

            boss1 = title_font.render("LEVEL 10 !!", True, (255, 255, 120))
            boss2 = big_font.render("BOSS STAGE !!", True, (255, 120, 120))

            screen.blit(boss1, (25, 220))
            screen.blit(boss2, (40, 290))


        elif level_message_timer > 0:
            
            level_text = title_font.render(level_message, True, (255, 180, 255))
            screen.blit(level_text, (70, 190))

        if game_over:
            overlay = pygame.Surface((FIELD_WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            screen.blit(overlay, (0, 0))

            draw_puyo(135, HEIGHT // 2 - 120, base_colors[0], radius=22, sad=True)

            over_text = big_font.render("GAME OVER", True, (255, 120, 120))
            level_text = font.render(f"Final Level: {final_level}", True, (255, 255, 255))
            score_text = font.render(f"Score: {score}", True, (255, 255, 255))
            retry_text = font.render("Press R to Retry", True, (255, 255, 255))

            screen.blit(over_text, (55, HEIGHT // 2 - 80))
            screen.blit(level_text, (88, HEIGHT // 2 - 40))
            screen.blit(score_text, (105, HEIGHT // 2 - 10))

            if continue_timer > 0:
                count = math.ceil(continue_timer / 30)
                cont_text = font.render(f"Continue? {count}", True, (255, 255, 120))
                space_text = font.render("Press SPACE", True, (255, 255, 255))
                screen.blit(cont_text, (88, HEIGHT // 2 + 25))
                screen.blit(space_text, (88, HEIGHT // 2 + 55))
            else:
                screen.blit(retry_text, (78, HEIGHT // 2 + 45))

        pygame.display.update()
        clock.tick(30)

        # Web版で必須：ブラウザへ処理を返す
        await asyncio.sleep(0)


asyncio.run(main())
